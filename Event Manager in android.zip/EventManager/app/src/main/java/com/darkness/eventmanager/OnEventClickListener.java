package com.darkness.eventmanager;

public interface OnEventClickListener {
    public void onClickListener(int position);
}
